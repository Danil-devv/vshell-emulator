#!/bin/sh
WORD="HELLO"
LIMIT=${#WORD}
i=0
while [ "$i" -lt "$((LIMIT+2))" ]
do
    if [ "${i}" = 0 ] ||  [ "${i}" = "$((LIMIT+1))" ]; 
    then 
       printf "+"
    else 
       printf "-"
    fi
    i=$((i+1))       
done
echo
printf "|${WORD}|"
echo
i=0
while [ "$i" -lt "$((LIMIT+2))" ]
do
    if [ "${i}" = 0 ] ||  [ "${i}" = "$((LIMIT+1))" ]; 
    then 
       printf "+"
    else 
       printf "-"
    fi
    i=$((i+1))       
done
echo
exit 0
